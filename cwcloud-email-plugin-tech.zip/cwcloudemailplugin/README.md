# cwc-prestashop-email

This is a prestashop module for using the [cwcloud](https://doc.cwcloud.tech/docs/tutorials/emailapi) email API.

Go see this documentation to get more details: https://doc.cwcloud.tech/docs/tutorials/emailapi
